create view pg_timezone_abbrevs(abbrev, utc_offset, is_dst) as
SELECT z.abbrev,
       z.utc_offset,
       z.is_dst
FROM pg_timezone_abbrevs_zone() z(abbrev, utc_offset, is_dst)
UNION ALL
SELECT a.abbrev,
       a.utc_offset,
       a.is_dst
FROM pg_timezone_abbrevs_abbrevs() a(abbrev, utc_offset, is_dst)
WHERE NOT (EXISTS (SELECT 1
                   FROM pg_timezone_abbrevs_zone() z2(abbrev, utc_offset, is_dst)
                   WHERE z2.abbrev = a.abbrev))
ORDER BY 1;

alter table pg_timezone_abbrevs
    owner to postgres;

grant select on pg_timezone_abbrevs to public;

