create view pg_stat_subscription_stats
            (subid, subname, apply_error_count, sync_error_count, confl_insert_exists, confl_update_origin_differs,
             confl_update_exists, confl_update_missing, confl_delete_origin_differs, confl_delete_missing,
             confl_multiple_unique_conflicts, stats_reset)
as
SELECT ss.subid,
       s.subname,
       ss.apply_error_count,
       ss.sync_error_count,
       ss.confl_insert_exists,
       ss.confl_update_origin_differs,
       ss.confl_update_exists,
       ss.confl_update_missing,
       ss.confl_delete_origin_differs,
       ss.confl_delete_missing,
       ss.confl_multiple_unique_conflicts,
       ss.stats_reset
FROM pg_subscription s,
     LATERAL pg_stat_get_subscription_stats(s.oid) ss(subid, apply_error_count, sync_error_count, confl_insert_exists,
                                                      confl_update_origin_differs, confl_update_exists,
                                                      confl_update_missing, confl_delete_origin_differs,
                                                      confl_delete_missing, confl_multiple_unique_conflicts,
                                                      stats_reset);

alter table pg_stat_subscription_stats
    owner to postgres;

grant select on pg_stat_subscription_stats to public;

